jQuery(document).ready(function(){

	jQuery("div#mas").closify();
	jQuery("div#abdu").closify();
	
	}
);
